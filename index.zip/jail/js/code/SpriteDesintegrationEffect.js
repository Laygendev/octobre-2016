var SpriteDesintegrationEffect = (function () {
    function SpriteDesintegrationEffect() {
    }
    return SpriteDesintegrationEffect;
}());
//# sourceMappingURL=SpriteDesintegrationEffect.js.map