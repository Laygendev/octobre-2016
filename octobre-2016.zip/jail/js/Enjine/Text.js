var TimerText = (function () {
    function TimerText(text) {
        this.text = text;
    }
    return TimerText;
}());
//# sourceMappingURL=Text.js.map