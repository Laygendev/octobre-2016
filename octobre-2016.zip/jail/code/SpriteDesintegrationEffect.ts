/**
Créer par Jimmy Latour, 2016
http://labodudev.fr
*/

class SpriteDesintegrationEffect {
	constructor() {
	}
}
